$(document).ready(function() {

    $('#datepicker-example1').Zebra_DatePicker();
    $('#datepicker-example2').Zebra_DatePicker();

});