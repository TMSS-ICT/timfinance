angular.module("app.Member", [
    'controller.Member',
    'controllers.ImageCopper',
    'ui.bootstrap'
]);

