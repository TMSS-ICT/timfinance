1. Session management
2. Remember me option
3. Idle timeout
4. Dynamic template
5. Routing
6. htaccess protection
7. Default Admin panel
8. Account/IP lock for wrong attempt
9. Remove index.php from the url