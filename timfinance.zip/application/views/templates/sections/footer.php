<div style=" margin-top: 500px;  width: 100%"></div>
    <div class="row padding_top_over_row">
        <div class="col-md-offset-1 col-md-10">
            <div style="color: #703684">
                <a href="<?php echo base_url(); ?>footer/about">About</a> | <a href="<?php echo base_url(); ?>footer/contact">Contact</a> | <a href="<?php echo base_url(); ?>member/invite">Invite</a> | <a href="<?php echo base_url(); ?>footer/privacy">Privacy</a> | <a href="<?php echo base_url(); ?>footer/terms">Terms</a>
            </div>
        </div>
        <div class="col-md-1"></div>
    </div>
</div>