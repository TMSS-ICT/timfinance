<header style="background-color: #00B050">
    <div class="">
        <div id="" class="row">
            
            <div class="col-md-offset-1 col-md-1">
                <a id="" tabindex="-1"   href="<?php echo base_url(); ?>">
                    <img class="img-responsive" style="size: "alt="TIMFinance" src="<?php echo base_url() ?>resources/images/logo.png"/>
                </a>
            </div>
            <div class="col-md-1">
                <p style="font-size: 30px; color: white">TIMFinance</p>
            </div>
            <div class="col-md-6"></div>
        </div>
    </div>
</header>