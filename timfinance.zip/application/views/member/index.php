<div class="row">
    <div class="col-md-12">
        <p style="font-size: 20px; text-align: center">TIMF প্রকল্প এলাকার জনগনের প্রাথমিক তথ্য বিবরণী </p>
    </div>
</div>
<div class="row col-md-12" style="margin-top: 25px">
    <div class=" row form-group form-inline">

        <div class=" col-md-3 form-group  ">
            <lebel class="" for="">জোন</lebel>
            <select class="" name="zone_name">
                <option>ঢাকা</option>
                <option>পাবনা</option>
                <option>বগুড়া</option>
                <option>নাটোর</option>
            </select>
        </div>

        <div class=" col-md-3 form-group">
            <lebel class="" for="">অঞ্চল</lebel>
            <select class="" name="area_name">
                <option>মিরপুর</option>
                <option>পবা</option>
                <option>বেড়া</option>
                <option>লালপুর</option>
            </select>
        </div>

        <div class=" col-md-3  form-group">
            <lebel class="" for="">শাখাঃ</lebel>
            <select class="" name="branch_name">
                <option>মিরপুর</option>
                <option>পবা</option>
                <option>বেড়া</option>
                <option>লালপুর</option>
            </select>
        </div>
        <div class="col-md-3">

        </div>

    </div>

    <div class=" row form-group form-inline">
        <div class="col-md-3">
            <lebel for="">নামঃ</lebel>
            <div class="form-group ">
                <select class="" name="name_title">
                    <option>নির্বাচন করুন</option>
                    <option>মোঃ</option>
                    <option>মোছাঃ</option>
                    <option>শ্রীঃ</option>
                    <option>শ্রীমতি</option>
                </select>
            </div>
        </div>
        <div class="col-md-3  form-group">
            <input class="" type="text" name="first_name" placeholder="১ম নামঃ">
        </div>
        <div class="col-md-3 form-group ">
            <input class="" type="text" name="last_name" placeholder="২য় নামঃ">
        </div>
        <div class="col-md-3 form-group">
            <select class="" name="family_name">
                <option>নির্বাচন করুন</option>
                <option>শেখ</option>
                <option>মোল্লা</option>
                <option>খান</option>
                <option>মণ্ডল</option>
            </select>
        </div>
    </div>
    <div class=" row form-group form-inline">

        <div class="form-group col-md-3">
            <lebel for="">লিঙ্গঃ</lebel>
            <select class="" name="gender_name">
                <option>নির্বাচন করুন</option>
                <option>পুরুষ</option>
                <option>মহিলা</option>
                <option>অন্যান্য</option>
            </select>
        </div>
        <div class="col-md-3">
            <lebel for="">বয়সঃ</lebel>
            <div class="form-group ">
                <select class="" name="age">
                    <option>নির্বাচন করুন</option>
                    <option>1</option>
                    <option>2</option>
                    <option>3</option>
                    <option>4</option>
                </select>
            </div>
        </div>

        <div class="col-md-3">
            <lebel for="">শিক্ষাগত যোগ্যতা(সর্বোচ্চ)</lebel>
            <select class="" name="educational_qualification">
                <option>নির্বাচন করুন</option>
                <option>এস এস সি</option>
                <option>এইচ এস সি</option>
                <option>অনার্স</option>
                <option>মাস্টার্স</option>
            </select>

        </div>
        <div class="col-md-3">
            <lebel for="">পাসের বছর</lebel>
            <select class="" name="gender_name">
                <option>নির্বাচন করুন</option>
                <option>2008</option>
                <option>2009</option>
                <option>2010</option>
            </select>
        </div>

    </div>

    <div class=" row form-group form-inline">

        <div class="col-md-6">

        </div>

    </div>

    <div class=" row form-group form-inline">
        <div class="col-md-3">
            <lebel for="">পিতা/স্বামীর নামঃ</lebel>
            <select class="" name="father/hasband_title">
                <option>নির্বাচন করুন</option>
                <option>মোঃ</option>

            </select>
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_first_name" placeholder="পিতার/স্বামীর ১ম নামঃ">
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_second_name" placeholder="পিতার/স্বামীর ২য় নামঃ">
        </div>
        <div class="col-md-2">

            <select class="" name="family_name">
                <option>পিতার/স্বামীর পারিবারিক নামঃ</option>
                <option>শেখ</option>
                <option>মোল্লা</option>
                <option>খান</option>
                <option>মণ্ডল</option>
            </select>
        </div>
        <div class="col-md-3">
            <lebel for="">অভিভাবকের পেশা</lebel>
            <div class="form-group ">

                <select class="" name="father/hasband_title">
                    <option>নির্বাচন করুন</option>
                    <option>কৃষি</option>
                    <option>চাকুরী</option>
                    <option>ব্যবসা</option>

                </select>
            </div>
        </div>
    </div>

    <div class=" row form-group form-inline">
        <div class="col-md-3">
            <lebel for="">মাতার নামঃ</lebel>
            <select class="" name="father/hasband_title">
                <option>নির্বাচন করুন</option>
                <option>মোছাঃ</option>
            </select>
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_first_name" placeholder="মাতার ১ম নামঃ">
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_second_name" placeholder="মাতার ২য় নামঃ">
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_second_name" placeholder="মাতার ২য় নামঃ">
        </div>
        <div class="col-md-3">
            <lebel for="">মাতার বয়স</lebel>
            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>30</option>
                <option>31</option>
                <option>32</option>
                <option>45</option>
            </select>
        </div>
    </div>

    <div class=" row form-group form-inline">
        <div class="col-md-3">
            <lebel for="">বর্তমান ঠিকানাঃ</lebel>
        </div>
        <div class="col-md-2">
            <lebel for="">দেশ</lebel>
            <select class="" name="father/hasband_title">
                <option>নির্বাচন করুন</option>
                <option>বাংলাদেশ</option>

            </select>
        </div>
        <div class="col-md-2">
            <lebel for="">জেলাঃ</lebel>
            <select class="" name="father/hasband_title">
                <option>নির্বাচন করুন</option>
                <option>পাবনা</option>

            </select>
        </div>
        <div class="col-md-2">
            <lebel for="">থানা</lebel>
            <select class="" name="father/hasband_title">
                <option>নির্বাচন করুন</option>
                <option>পাবনা</option>

            </select>
        </div>
        <div class="col-md-2">
            <lebel for="">ইউনিয়ন</lebel>
            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>আমিনপুর</option>
                <option>জহিরপুর</option>
                <option>দেবত্তর</option>

            </select>
        </div>
    </div>

    <div class=" row form-group form-inline">
        <div class="col-md-3">

        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_first_name" placeholder="পোষ্ট অফিস">
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_first_name" placeholder="গ্রাম বা মহল্লা">
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_first_name" placeholder="রাস্তা নং">
        </div>
    </div>

    <div class=" row form-group form-inline">
        <div class="col-md-3">
            <lebel for="">স্থায়ী ঠিকানাঃ</lebel>
        </div>
        <div class="col-md-2">
            <lebel for="">দেশ</lebel>
            <select class="" name="father/hasband_title">
                <option>নির্বাচন করুন</option>
                <option>বাংলাদেশ</option>

            </select>
        </div>
        <div class="col-md-2">
            <lebel for="">জেলাঃ</lebel>
            <select class="" name="father/hasband_title">
                <option>নির্বাচন করুন</option>
                <option>পাবনা</option>

            </select>
        </div>
        <div class="col-md-2">
            <lebel for="">থানা</lebel>
            <select class="" name="father/hasband_title">
                <option>নির্বাচন করুন</option>
                <option>পাবনা</option>

            </select>
        </div>
        <div class="col-md-2">
            <lebel for="">ইউনিয়ন</lebel>
            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>আমিনপুর</option>
                <option>জহিরপুর</option>
                <option>দেবত্তর</option>

            </select>
        </div>
    </div>

    <div class=" row form-group form-inline">
        <div class="col-md-3">

        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_first_name" placeholder="পোষ্ট অফিস">
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_first_name" placeholder="গ্রাম বা মহল্লা">
        </div>
        <div class="col-md-2">
            <input type="text" name="father/hasband_first_name" placeholder="রাস্তা নং">
        </div>
    </div>

    <div class="row form-group form-inline">

        <div class="col-md-3">
            <lebel for="">যোগাযোগঃ</lebel>
        </div>
        <div class="col-md-2">
            <input type="number" name="father/hasband_first_name" placeholder="মোবাইল নং">
        </div>
        <div class="col-md-2">
            <input type="number" name="father/hasband_first_name" placeholder="ইমেইল">
        </div>
        <div class="col-md-2">
            <input type="number" name="father/hasband_first_name" placeholder="অভিভাবকের মোবাইল নং">
        </div>

        <div class="col-md-3">

        </div>

    </div>

    <div class="row form-group form-inline">

        <div class="col-md-3">
            <lebel for="">দুরুত্ব (কিঃ মিঃ)</lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>দুরুত্ব (কিঃ মিঃ)</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
            </select>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>বৈবাহিক অবস্থা</option>
                <option>বিবাহিত একক</option>
                <option>বিবাহিত বহু</option>
                <option>অবিবাহিত</option>
                <option>বিপত্নীক</option>
                <option>বিধবা</option>
            </select>

        </div>

        <div class="col-md-3">

        </div>

    </div>

    <div class="row form-group form-inline">

        <div class="col-md-3">
            <lebel for="">পেশা</lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>কৃষি</option>
                <option>চাকুরী</option>
                <option>ব্যাবসা</option>
                <option>অন্যান্য</option>

            </select>
        </div>

        <div class="col-md-3">
            <lebel for="">বর্তমান পেশার পূর্বে তিনি কি করতেন</lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <
                <option>নির্বাচন করুন</option>
                <option>কৃষি</option>
                <option>চাকুরী</option>
                <option>ব্যাবসা</option>
                <option>অন্যান্য</option>
            </select>

        </div>

    </div>

    <div class="row form-group form-inline">

        <div class="col-md-3">
            <lebel for="">সেই পেশায় কতদিন নিয়োজিত ছিলেন</lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>মাস</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
            </select>
        </div>

        <div class="col-md-2">
            <textarea  row ="2" class="form-control" name="alternative_earning_source">ব্যবসা/চাকুরী করে অর্জিত সম্পদের বিবরণ</textarea >
        </div>

        <div class="col-md-1">
            </div>


        <div class="col-md-2">
            <textarea  row ="2" class="form-control" name="alternative_earning_source">ব্যবসা ছাড়া আয়ের উৎস থাকলে তার বিবরণ</textarea >
        </div>

    </div>

    <div class="row form-group form-inline">

        <div class="col-md-3">
            <lebel for="">রাজনীতির সাথে জরিত কি না- </lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>হ্যাঁ</option>
                <option>না</option>

            </select>
        </div>

        <div class="col-md-2">
            <lebel for="">ব্যবসার ধরন</lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>একক</option>
                <option>অংশীদারি</option>

            </select>
        </div>
        <div class="col-md-2">
            <textarea  row ="2" name="alternative_earning_source">ব্যবসার ভবিষ্যৎ পরিকল্পনা</textarea >
        </div>

    </div>

    <div class="row form-group form-inline">

        <div class="col-md-3">
            <lebel for="">পরিবারের প্রকৃতি </lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>একক</option>
                <option>যৌথ</option>

            </select>
        </div>

        <div class="col-md-2">
            <lebel for="">পরিবারের সদস্য সংখ্যা</lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>

            </select>
        </div>


    </div>

    <div class="row form-group form-inline">

        <div class="col-md-3">
            <lebel for="">উপার্জনক্ষম পুরুষের সংখ্যা</lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>

            </select>
        </div>

        <div class="col-md-3">
            <lebel for="">উপার্জনক্ষম মহিলার সংখ্যা</lebel>
        </div>

        <div class="col-md-2">

            <select class="" name="father/hasband_family_name">
                <option>নির্বাচন করুন</option>
                <option>1</option>
                <option>2</option>
                <option>3</option>
                <option>4</option>
                <option>5</option>
                <option>6</option>

            </select>
        </div>

        <div class="col-md-2">
            <textarea  row ="2" name="alternative_earning_source">পরিবারের কেউ গুরুতর অসুস্থ থাকলে তার বিবরণ</textarea >
        </div>
        <div class="col-md-2">
        </div>



    </div>

    <div class="row">



    </div>

      <div class="row form-group form-inline">
        <div class=" col-md-2 pull-right">
            <input id="search_submit_btn" type="submit"  value="Save" onclick="search_payment_history()" class="button-custom ">
        </div>
    </div>
</div>

